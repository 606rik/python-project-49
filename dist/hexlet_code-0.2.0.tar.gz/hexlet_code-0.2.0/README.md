[![Maintainability](https://api.codeclimate.com/v1/badges/74f38d9995ff1738325e/maintainability)](https://codeclimate.com/github/606rik/python-project-49/maintainability)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/606rik/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/606rik/python-project-49/actions)


#ссылка на asciinema: https://asciinema.org/a/2CPLxIAxfFLhPdtCO13kZ6cji
#ссылка на asciinema: https://asciinema.org/a/yNnI6M6fv9UUNrWqs8IrJp05l
#ссылка на asciinema: https://asciinema.org/a/FLwlJEZ7QhTcmhdQBsaIF7UXF
#ссылка на asciinema:https://asciinema.org/a/jbzojpSx2Db4ituzJMdWb0BjH